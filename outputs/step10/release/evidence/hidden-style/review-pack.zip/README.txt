PS1 REVIEW PACK
For Step 8 revisions, inputs/ contains changed inputs and planning-context.json defines explicit weekly supply overrides. Revalidate with --planning-context planning-context.json; the three schedule CSVs alone do not encode the disruption. replanning.json and parent/ retain before/after evidence.
Not an officially validated submission.
Protection remains unverified. Incomplete contracts have no fabricated completion rows.
See validation.json for completeness and construction.json for generated-run decisions and unfinished work.
planner-review.json contains comments and decisions for the exact schedule version in manifest.json. Reviewer names are self-entered, not authenticated signatures.
alternative.json contains the selected conflict and checked comparison when this run was generated as an alternative.
No planner decision grants operational track-entry authority.
